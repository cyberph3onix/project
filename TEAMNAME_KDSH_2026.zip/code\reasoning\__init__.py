# Reasoning module
